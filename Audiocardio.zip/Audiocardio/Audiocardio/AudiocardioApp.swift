//
//  AudiocardioApp.swift
//  Audiocardio
//
//  Created by GoldenBeast on 11/29/24.
//

import SwiftUI

@main
struct AudiocardioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
